#!/usr/bin/env python3

from Vehicle import Vehicle
from ExceptionProcess import ExceptionProcess
from ExceptionVehicle import ExceptionVehicle


class CollectorsVehicle (Vehicle):
    def __init__(self, list1):
        try:
            exp=ExceptionProcess()
            exp.CheckList(list1, "CollectorVehicle")
            super().__init__(list1[0:6])
            exp.CheckIntNumbers(list1[6], "CollectorVehicle", 0)
            self.km = list1[6]
            exp.CheckIntNumbers(list1[7], "CollectorVehicle",0)
            self.old_owners = list1[7]
            exp.CheckTuple(list1[8], "CollectorVehicle",  2)
            self.Test = list1[8]
        except ExceptionVehicle as e:
            print(f"Exception has been raised:\n{e}")

    def print_me(self):
        super().print_me()
        print(f"KM: {self.km}")
        print(f"number of old owners: {self.old_owners}")
        print(f"Test: {self.Test}")

    def __str__(self):
        back = super().__str__()
        back += f", {self.km}, {self.old_owners}, {self.Test}"
        return back

    def __repr__(self):
        return str(self)

    def IsCollector (self):
        return True

