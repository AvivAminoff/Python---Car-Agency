#!/usr/bin/env python3

from ExceptionProcess import ExceptionProcess
from ExceptionVehicle import ExceptionVehicle

class Customer:
    def __init__(self,list2):
        try:
            exp=ExceptionProcess()
            exp.CheckList(list2, "Customer")
            exp.CheckIntNumbers(list2[0], "Customer",0)
            self.customer_id = list2[0]
            exp.CheckSTR(list2[1], "Customer")
            self.name = list2[1]
            exp.CheckSTR(list2[2], "Customer")
            self.address = list2[2]
            exp.CheckSTR(list2[3], "Customer")
            exp.CheckPhoneNum(list2[3], "Customer")
            self.phone_number = list2[3]
            exp.CheckSTR(list2[4], "Customer")
            self.gender = exp.CheckGender(list2[4], "Customer")
        except ExceptionVehicle as e:
            print(f"Excpetion has been found\n{e}")
#c
    def print_me(self):
        print(f"id:{self.customer_id}")
        print(f"name: {self.name}")
        print(f"address: {self.address}")
        print(f"phone number: {self.phone_number}")
        print(f"gender:{self.gender}")
#d
    def __str__(self):
        back = f"{self.customer_id}, {self.name}, {self.address}, {self.phone_number}, {self.gender}"
        return back

    def __repr__(self):
        return str(self)

