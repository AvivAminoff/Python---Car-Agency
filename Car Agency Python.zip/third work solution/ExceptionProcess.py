#!/usr/bin/env python3

from ExceptionVehicle import ExceptionVehicle

class ExceptionProcess():
    def __init__(self):
        pass

    def CheckIntNumbers(self, var, source, minimum = None, maximum =None):
        if type(var) is not int:
            message = f"var type is not int"
            raise ExceptionVehicle(message, 3, source)
        if minimum is not None:
            if var < minimum:
                message = f"integer is less then minimum allowed"
                raise ExceptionVehicle(message, 5, source)
        if maximum is not None:
            if var > maximum:
                message = f"integer is more then maximum allowed"
                raise ExceptionVehicle(message, 5, source)

    def CheckSTR(self, var, source):
        if type(var) is not str :
            message = f"var must be string!"
            raise ExceptionVehicle(message, 4, source)
        if len(var) == 0:
            message = f"string is empty"
            raise ExceptionVehicle(message, 4, source)

    def CheckList(self, var, source):
        if type(var) is not list:
            message = f"var is not list"
            raise ExceptionVehicle(message, 3, source)
        if len(var) == 0:
            message = f"list is empty!"
            raise ExceptionVehicle(message, 5, source)

    def CheckTuple(self, var, source, Length):
        if type(var) is not tuple:
            message = f"var is not tuple"
            raise ExceptionVehicle(message, 3, source)
        if len(var) != Length:
            message = f"tuple length is invalid"
            raise ExceptionVehicle(message, 2, source)

    def CheckDict(self, var, source):
        if type(var) is not dict:
            message = f"var type is not dictionary"
            raise ExceptionVehicle(message, 3, source)

    def CheckPhoneNum (self,var,source):
        if len(var) != 10:
            message = "phone number must be 10 digits"
            raise ExceptionVehicle(message, 3, source)

    def CheckGender(self,var, source):
        if var.strip().upper() == "F" or var.strip().upper() == "M":
            return var.strip().upper()
        else:
            message = "gender must be F or M"
            raise ExceptionVehicle(message, 3, source)

    def CheckJoiningPresent(self, var, source):
        if type(var) is not bool and type(var) is not str and var != None:
            message = f"var type is not bool or string"
            raise ExceptionVehicle(message, 3, source)
        if type(var) is bool or var == None:
            if var == None or var == True:
                return True
            if var == False:
                return False
        if type(var) is str:
            if len(var) == 0:
                message = f"Joining Present is empty string!"
                raise ExceptionVehicle(message, 5, source)
            if var != "True" and var != "False" and var != "true" and var != "false":
                message = f"Joining Present must be True or False!"
                raise ExceptionVehicle(message, 5, source)
            if var == "True" or var == "true":
                return True
            if var == "False" or var == "false":
                return False

    def CheckVehicle(self, var, source):
        from Vehicle import Vehicle
        if not isinstance(var,Vehicle):
            message = "must insert a Vehicle object"
            raise ExceptionVehicle(message, 5, source)

    def CheckCustomer(self, var, source):
        from Customer import Customer
        if not isinstance(var,Customer):
            message = "must insert a Customer object"
            raise ExceptionVehicle(message, 5, source)
