#!/usr/bin/env python3
#
class ExceptionVehicle(Exception):
    def __init__(self, Message, Level, Source):
        self.Message = Message
        self.Level = Level
        self.Source = Source

    def __str__(self):
        str1 = f"The Error is {self.Message}\n"
        str1 += f"The level of severity is {self.Level}\n"
        str1 += f"The source is object {self.Source}\n"
        return str1

    def __repr__(self):
        str1 = f"Error: {self.Message}\n"
        str1 += f"Level: {self.Level}\n"
        str1 += f"Source: {self.Source}\n"
        return str1
