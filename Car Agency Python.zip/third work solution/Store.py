#!/usr/bin/env python3

from Collectorsvehicle import CollectorsVehicle
from VIPCustomer import VIPCustomer
from Vehicle import Vehicle
from Customer import Customer
from ExceptionProcess import ExceptionProcess
from ExceptionVehicle import ExceptionVehicle

import csv

class Store:
    def __init__(self, file1, file2):
        self.vehicles = []
        with open(file1) as csvfile1:
            read1 = csv.reader(csvfile1)
            next(read1)
            try:
                for row in read1:
                    if len(row) == 6:
                        list1 = [int(row[0]), row[1], row[2], row[3], int(row[4]), int(row[5])]
                        self.vehicles.append(Vehicle(list1))
                    else:
                        list1 = [int(row[0]), row[1], row[2], row[3], int(row[4]), int(row[5]), int(row[6]), int(row[7]), eval(row[8])]
                        self.vehicles.append(CollectorsVehicle(list1))
            except ExceptionVehicle as e1:
                print(f"there is an exception:\n{e1}")
            except ValueError as e2:
                print(f"there is an exception:\n{e2}")
            except:
                print(f"there is an exception")

        self.customers = []
        with open(file2) as csvfile2:
            read2 = csv.reader(csvfile2)
            next(read2)
            try:
                for row in read2:
                    if len(row) == 5:
                        list2 = [int(row[0]), row[1], row[2], row[3], row[4]]
                        self.customers.append(Customer(list2))
                    else:
                        list2 = [int(row[0]), row[1], row[2], row[3], row[4], eval(row[5]), eval(row[6])]
                        self.customers.append(VIPCustomer(list2, row[7]))
            except ExceptionVehicle as e1:
                print(f"there is an exception:\n{e1}")
            except ValueError as e2:
                print(f"there is an exception:\n{e2}")
            except:
                print(f"there is an exception")

    def print_vehicles(self):
        for vehicle in self.vehicles:
            print(vehicle)

    def get_vehicle(self, licence_plate):
        exp=ExceptionProcess()
        exp.CheckIntNumbers(licence_plate, "Store", 0, 99999999)
        for vehicle in self.vehicles:
            if vehicle.licence_plate == licence_plate:
               return vehicle

        return None

    def add_vehicle(self, vehicle):
        exp = ExceptionProcess()
        exp.CheckVehicle(vehicle, "Store")

        if self.get_vehicle(vehicle.licence_plate) is not None:
            return False

        self.vehicles.append(vehicle)
        return True


    def remove_vehicle(self,licence_plate):
        exp=ExceptionProcess()
        exp.CheckIntNumbers(licence_plate, "Store", 0, 99999999)
        vehicle = self.get_vehicle(licence_plate)
        if vehicle is not None:
            self.vehicles.remove(vehicle)
            return True

        return False

    def get_all_by_manufacturer(self,manufacturer):
        exp=ExceptionProcess()
        exp.CheckSTR(manufacturer, "Store")
        vehicles_by_manufacturer =[]
        for vehicle in self.vehicles:
            if vehicle.manufacturer == manufacturer:
                vehicles_by_manufacturer.append(vehicle)

        return vehicles_by_manufacturer

    def get_all_by_price_under (self,price):
        exp=ExceptionProcess()
        exp.CheckIntNumbers(price, "Store", 0)
        vehicles_by_price =[]
        for vehicle in self.vehicles:
            if vehicle.price < price:
                vehicles_by_price.append(vehicle)

        return vehicles_by_price

    def print_vehicles_list(self, vehicles):
        exp=ExceptionProcess()
        exp.CheckList(vehicles, "Store")
        for vehicle in vehicles:
            exp = ExceptionProcess()
            exp.CheckVehicle(vehicle, "Store")
            vehicle.print_me()

    def get_most_expensive_vehicle(self):
        if len(self.vehicles) == 0:
            return None

        most_expensive_vehicle = self.vehicles[0]

        for vehicle in self.vehicles:
            if vehicle.price > most_expensive_vehicle.price:
                most_expensive_vehicle = vehicle

        return most_expensive_vehicle


    def print_customers(self):
        for customer in self.customers:
            print(customer)

    def get_customer(self, customer_id):
        exp=ExceptionProcess()
        exp.CheckIntNumbers(customer_id, "Store", 0)
        for customer in self.customers:
            if customer.customer_id == customer_id:
                return customer

        return None


    def add_customer(self, customer):
        exp = ExceptionProcess()
        exp.CheckCustomer(customer, "Store")

        if self.get_customer(customer.customer_id):
            return False

        self.customers.append(customer)
        return True


    def remove_customer(self,customer_id):
        exp=ExceptionProcess()
        exp.CheckIntNumbers(customer_id, "Store", 0)
        customer = self.get_customer(customer_id)
        if customer is not None:
            self.customers.remove(customer)
            return True

        return False

    def Gett_all_Collector(self):
        all_collector = []
        for vehicle in self.vehicles:
            if vehicle.IsCollector() == True:
                all_collector.append(vehicle)

        return all_collector


    def Gett_all_by_KM(self, km):
        exp=ExceptionProcess()
        exp.CheckIntNumbers(km, "Store", 0)
        vehicles_by_KM = []
        for vehicle in self.Gett_all_Collector():
            if vehicle.km < km:
                vehicles_by_KM.append(vehicle)

        return vehicles_by_KM


    def Gett_all_VIP(self):
        all_VIP = []
        for customer in self.customers:
            if isinstance(customer,VIPCustomer):
                all_VIP.append(customer)

        return all_VIP


    def Get_all_entitled(self):
        customers_entitled = []
        for vip in self.Gett_all_VIP():
            if vip.JoiningPresent == True:
                customers_entitled.append(vip)

        return customers_entitled



