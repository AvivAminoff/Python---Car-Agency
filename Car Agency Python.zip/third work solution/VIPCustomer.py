#!/usr/bin/env python3

from Customer import Customer
from ExceptionProcess import ExceptionProcess
from ExceptionVehicle import ExceptionVehicle

class VIPCustomer (Customer):
    def __init__(self, list2, JoiningPresent=None):
        try:
            exp=ExceptionProcess()
            exp.CheckList(list2, "VIPCustomer")
            super().__init__(list2[0:5])
            exp.CheckTuple(list2[5], "VIPCustomer", 3)
            self.StartDate = list2[5]
            exp.CheckTuple(list2[6], "VIPCustomer", 3)
            self.BirthDate = list2[6]
            self.JoiningPresent = exp.CheckJoiningPresent(JoiningPresent, "VIPCustomer")
        except ExceptionVehicle as e:
            print(f"Excpetion has been raised:\n{e}")

    def __str__(self):
        back = super().__str__()
        back += f", {self.StartDate}, {self.BirthDate}, {self.JoiningPresent}"
        return back

    def __repr__(self):
        return str(self)

    def GetPresent(self):
        if self.JoiningPresent == False:
            print("You already got your present")
        if self.JoiningPresent == True:
            print("Congratulations here is your present")
            self.JoiningPresent = False


