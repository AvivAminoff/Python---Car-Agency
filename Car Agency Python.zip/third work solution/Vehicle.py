#!/usr/bin/env python3

from ExceptionVehicle import ExceptionVehicle
from ExceptionProcess import ExceptionProcess

class Vehicle:
    def __init__(self,list1):
        try:
            exp=ExceptionProcess()
            exp.CheckList(list1, "Vehicle")
            exp.CheckIntNumbers(list1[0], "Vehicle", 0, 99999999)
            self.licence_plate = list1[0]
            exp.CheckSTR(list1[1], "Vehicle")
            self.vehicle_type = list1[1]
            exp.CheckSTR(list1[2], "Vehicle")
            self.manufacturer = list1[2]
            exp.CheckSTR(list1[3], "Vehicle")
            self.model = list1[3]
            exp.CheckIntNumbers(int(list1[4]), "Vehicle", 1900, 2022)
            self.year = list1[4]
            exp.CheckIntNumbers(list1[5], "Vehicle", 1000, 3000000)
            self.price = list1[5]
        except ExceptionVehicle as e:
            print(f"there is an exception:\n{e}")



    def print_me(self):
        print(f"---- {self.licence_plate} ----")
        print(f"type:{self.vehicle_type}")
        print(f"manufacturer: {self.manufacturer}")
        print(f"model: {self.model}")
        print(f"year: {self.year} ")
        print(f"price: {self.price} NIS")

    def __str__(self):
        back = f"{self.licence_plate}, {self.vehicle_type}, {self.manufacturer}, {self.model}, {self.year}, {self.price}"
        return back

    def __repr__(self):
        return str(self)


    def IsCollector (self):
        return False


