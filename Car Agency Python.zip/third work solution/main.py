#!/usr/bin/env python3

from Collectorsvehicle import CollectorsVehicle
from Customer import Customer
from Store import Store
from VIPCustomer import VIPCustomer
from Vehicle import Vehicle
from ExceptionVehicle import ExceptionVehicle
from tkinter import *
import tkinter.ttk as ttk

iserror=False

def main():
    try:
        store= Store("vehicles.csv", "customers.csv")
        window = Tk()
        window.geometry("1100x500")
        head_label = Label(window, text = "Buy a Car", fg = "pink", font = ("Arial Bold", 30))
        head_label.grid(row = 0, column = 3)
        status_label = Label(window, text="welcome to my store!")
        status_label.grid(row=1, column=3)

        def handle_print_c():
            status_label.config(text="printing all customers",fg="purple")
            print("*** All Customers: ***")
            store.print_customers()

        print_c_btn = Button(window, text="print all customers", command=handle_print_c)
        print_c_btn.grid(row = 2, column = 4)

        def handle_print_v():
            status_label.config(text="printing all vehicles", fg="purple")
            print("*** All Vehicles: ***")
            store.print_vehicles()

        print_v_btn = Button(window, text="print all vehicles", command=handle_print_v)
        print_v_btn.grid(row=2, column=0)

        def handle_add_v():
            try:
                if len(add_v_entry.get()) == 0:
                    status_label.config(text="you need to enter vehicle data!", fg="red")
                if len(add_v_entry.get()) > 0:
                    txt = add_v_entry.get().split(',,')
                    if chk_v.get():
                        v = CollectorsVehicle([int(txt[0]), txt[1], txt[2], txt[3], int(txt[4]), int(txt[5]), int(txt[6]), int(txt[7]),eval(txt[8])])
                    else:
                        v = Vehicle([int(txt[0]), txt[1], txt[2], txt[3], int(txt[4]), int(txt[5])])
                    res = store.add_vehicle(v)
                    if res == True:
                        status_label.config(text="vehicle added", fg="green")
                    if res == False:
                        status_label.config(text="vehicle already exist", fg="red")
                    store.print_vehicles()
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! please enter valid parameters for vehicle")

        add_v_label = Label(window,text="Enter vehicle data (seprated with ',,'):", fg="blue")
        add_v_label.grid(row=5,column=0)
        add_v_entry=Entry(window,width=30)
        add_v_entry.grid(row=6,column=0)
        chk_v = BooleanVar()
        chk=Checkbutton(window,text="is collector vehicle?",var=chk_v)
        chk.grid(row=6,column=1)
        add_v_but=Button(window,text="add Vehicle", command=handle_add_v)
        add_v_but.grid(row=6,column=2)

        def handle_remove_v():
            try:
                if len(license_plate_entry.get()) == 0:
                    status_label.config(text="you need to enter license plate number!", fg="red")
                if len(license_plate_entry.get()) > 0:
                    txt = int(license_plate_entry.get())
                    res = store.remove_vehicle(txt)
                    if res == True:
                        status_label.config(text="vehicle removed", fg="green")
                    if res == False:
                        status_label.config(text="vehicle does not exist", fg="red")
                    store.print_vehicles()
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! license plate must be a number.")

        license_plate_label = Label(window, text="Enter vehicle license plate:", fg="blue")
        license_plate_label.grid(row=7, column=0)
        license_plate_entry = Entry(window, width=30)
        license_plate_entry.grid(row=8, column=0)
        remove_v_but = Button(window, text="remove Vehicle", command=handle_remove_v)
        remove_v_but.grid(row=8, column=1)

        def handle_get_m():
            if len(m_entry.get()) == 0:
                status_label.config(text="you need to enter a manufacturer!", fg="red")
            if len(m_entry.get()) > 0:
                status_label.config(text="printing all by manufacturer", fg="green")
                txt = m_entry.get().capitalize()
                print(f"*** All {txt}s: ***")
                mlist = store.get_all_by_manufacturer(txt)
                for vehicle in mlist:
                    vehicle.print_me()

        enter_m_label = Label(window, text="Enter manufacturer:", fg="blue")
        enter_m_label.grid(row=9, column=0)
        m_entry = Entry(window, width=30)
        m_entry.grid(row=10, column=0)
        get_m_but = Button(window, text="get all by manufacturer", command=handle_get_m)
        get_m_but.grid(row=10, column=1)

        def handle_get_p():
            try:
                if len(p_entry.get()) == 0:
                    status_label.config(text="you need to enter a price!", fg="red")
                if len(p_entry.get()) > 0:
                    txt = int(p_entry.get())
                    status_label.config(text=f"printing all under price {txt}", fg="green")
                    print(f"*** All under {txt}: ***")
                    plist = store.get_all_by_price_under(txt)
                    for vehicle in plist:
                        vehicle.print_me()
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! price must be a number.")

        enter_p_label = Label(window, text="Enter price:", fg="blue")
        enter_p_label.grid(row=11, column=0)
        p_entry = Entry(window, width=30)
        p_entry.grid(row=12, column=0)
        get_p_but = Button(window, text="get all under price", command=handle_get_p)
        get_p_but.grid(row=12, column=1)

        def handle_get_most_expensive():
            status_label.config(text="getting most expensive vehicle", fg="purple")
            most_exp = store.get_most_expensive_vehicle()
            most_exp.print_me()
            most_exp_label = Label(window, text=f"The most expensive vehicle is:\n {most_exp.licence_plate} - {most_exp.vehicle_type} {most_exp.manufacturer} {most_exp.model}", fg="blue")
            most_exp_label.grid(row=13, column=1)

        get_most_exp_but = Button(window, text="get most expensive vehicle", command=handle_get_most_expensive)
        get_most_exp_but.grid(row=13, column=0)

        def handle_get_v():
            try:
                if len(license_plate_entry.get()) == 0:
                    status_label.config(text="you need to enter license plate number!", fg="red")
                if len(license_plate_entry.get()) > 0:
                    txt = int(license_plate_entry.get())
                    if store.get_vehicle(txt):
                        print(store.get_vehicle(txt))
                        status_label.config(text="got it", fg="green")
                    else:
                        status_label.config(text="vehicle does not exist", fg="red")
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! license plate must be a number.")


        get_v_but = Button(window, text="get Vehicle", command=handle_get_v)
        get_v_but.grid(row=8, column=2)

        def handle_add_c():
            try:
                if len(add_c_entry.get()) == 0:
                    status_label.config(text="you need to enter customer data!", fg="red")
                if len(add_c_entry.get()) > 0:
                    txt = add_c_entry.get().split(',,')
                    if chk_c.get():
                        c = VIPCustomer([int(txt[0]), txt[1], txt[2], txt[3], txt[4], eval(txt[5]), eval(txt[6])],txt[7])
                    else:
                        c = Customer([int(txt[0]), txt[1], txt[2], txt[3], txt[4]])
                    res = store.add_customer(c)
                    if res == True:
                        status_label.config(text="customer added", fg="green")
                    if res == False:
                        status_label.config(text="customer already exist", fg="red")
                    store.print_customers()
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! please enter valid parameters for customer.")

        add_c_label = Label(window,text="Enter customer data (seprated with ',,'):", fg="blue")
        add_c_label.grid(row=5,column=4)
        add_c_entry=Entry(window,width=30)
        add_c_entry.grid(row=6,column=4)
        chk_c = BooleanVar()
        chkc = Checkbutton(window, text="is vip customer?", var=chk_c)
        chkc.grid(row=6, column=5)
        add_c_but=Button(window,text="add Customer", command=handle_add_c)
        add_c_but.grid(row=6,column=6)

        def handle_remove_c():
            try:
                if len(cus_id_entry.get()) == 0:
                    status_label.config(text="you need to enter customer id!", fg="red")
                if len(cus_id_entry.get()) > 0:
                    txt = int(cus_id_entry.get())
                    res = store.remove_customer(txt)
                    if res == True:
                        status_label.config(text="customer removed", fg="green")
                    if res == False:
                        status_label.config(text="customer does not exist", fg="red")
                    store.print_customers()
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! customer id must be a number.")

        cus_id_label = Label(window, text="Enter customer id:", fg="blue")
        cus_id_label.grid(row=7, column=4)
        cus_id_entry = Entry(window, width=30)
        cus_id_entry.grid(row=8, column=4)
        remove_c_but = Button(window, text="remove customer", command=handle_remove_c)
        remove_c_but.grid(row=8, column=5)

        def handle_get_c():
            try:
                if len(cus_id_entry.get()) == 0:
                    status_label.config(text="you need to enter customer id!", fg="red")
                if len(cus_id_entry.get()) > 0:
                    txt = int(cus_id_entry.get())
                    if store.get_customer(txt):
                        print(store.get_customer(txt))
                        status_label.config(text="got it", fg="green")
                    else:
                        status_label.config(text="customer does not exist", fg="red")
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! customer id must be a number.")

        get_c_but = Button(window, text="get customer", command=handle_get_c)
        get_c_but.grid(row=8, column=6)

        def handle_print_cv():
            status_label.config(text="printing all collectors vehicles", fg="purple")
            print("*** All Collectors: ***")
            all_c = store.Gett_all_Collector()
            for vehicle in all_c:
                print(vehicle)

        print_cv_but = Button(window, text="print all collectors vehicles", command=handle_print_cv)
        print_cv_but.grid(row=3, column=0)

        def handle_get_k():
            try:
                if len(k_entry.get()) == 0:
                    status_label.config(text="you need to enter a km!", fg="red")
                if len(k_entry.get()) > 0:
                    txt = int(k_entry.get())
                    status_label.config(text=f"printing all under {txt} km", fg="green")
                    print(f"*** All under {txt} KM: ***")
                    klist = store.Gett_all_by_KM(txt)
                    for vehicle in klist:
                        print(vehicle)
            except ValueError:
                global iserror
                iserror = True
                print(f"There is a Value error! KM must be a number.")

        enter_k_label = Label(window, text="Enter km:",fg="blue")
        enter_k_label.grid(row=14, column=0)
        k_entry = Entry(window, width=30)
        k_entry.grid(row=15, column=0)
        get_k_but = Button(window, text="get all under km", command=handle_get_k)
        get_k_but.grid(row=15, column=1)

        def handle_print_vip():
            status_label.config(text="printing all vip customers",fg="purple")
            print("*** All VIP Customers: ***")
            all_vip = store.Gett_all_VIP()
            for customer in all_vip:
                print(customer)

        print_vip_btn = Button(window, text="print all vip customers", command=handle_print_vip)
        print_vip_btn.grid(row = 3, column = 4)

        def handle_print_e():
            status_label.config(text="printing all entitled customers", fg="purple")
            print("*** All Customers Entitled: ***")
            all_e = store.Get_all_entitled()
            for customer in all_e:
                print(customer)

        print_e_btn = Button(window, text="print all entitled customers", command=handle_print_e)
        print_e_btn.grid(row = 4, column = 4)


        window.mainloop()

    except ExceptionVehicle as e:
        print(e)
    except ValueError as e1:
        print(f"There is an exception1111!")
    except :
        print(f"There is an exception!")
    else:
        if iserror == False:
            print("All good")

    print("continue")

main()

